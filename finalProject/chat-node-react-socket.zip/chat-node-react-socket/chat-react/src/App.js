import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';

// console.log(1)
// const socket = io()

// const userInputName = document.querySelector('.userInputName')
// const userInputRoom = document.querySelector('.userInputRoom')
// const chat = document.querySelector('.chat-form')
// const Input = document.querySelector('.chat-input')
// const chatWindow = document.querySelector('.chat-window') 

// const namef = (e) => {
//   socket.emit('userName', e.target.value)
// }
// // userInputName.addEventListener('change', namef)
// const roomf = (e) => {
//   socket.emit('userRoom', e.target.value)
// }
// // userInputRoom.addEventListener('change', roomf)


// chat.addEventListener('submit', event => {
//   event.preventDefault()
//   socket.emit('chat', Input.value)
//   Input.value = ''
// })

// socket.on('chat', chat => {
//   console.log('From server: ', chat)
//   let div = document.createElement('div')
//   let strong = document.createElement('strong')
//   let p = document.createElement('p')
//   strong.textContent = chat.userName + ': '
//   p.appendChild(strong)
//   let text = document.createTextNode(chat.message);
//   p.appendChild(text)
//   div.appendChild(p)
//   chatWindow.appendChild(div)
// })

let socket;
function App() {
  const [userInputName, setUserInputName] = useState('');
  const [userInputNumber, setUserInputNumber] = useState('');
  const [sendInputNumber, setSendInputNumber] = useState('');
  const [chatInput, setChatInput] = useState('');
  const ENDPOINT = 'http://localhost:5000/';

  useEffect(() => {
        socket = io(ENDPOINT);

        // socket.emit('join', { name, room }, () => {

        // });

        // return () => {
        //     socket.emit('disconnect');

        //     socket.off();
        // }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault()
    console.log(chatInput)
     socket.emit('chat', chatInput)
  }

  const namef = (e) => {
  socket.emit('userName', e.target.value)
  }

  const userNumberf = (e) => {
    socket.emit('userNumber', e.target.value)
  }

  const sendNumberf = (e) => {
    console.log(e.target.value)
    socket.emit('sendNumber', e.target.value)
  }


  return (
    <>
    <div id="container">
      <h1>
        Nodejs + Socket Chat app
      </h1>
      <input onChange={(e)=> namef(e) } type="text" name="userInputName" placeholder="write your name" className="userInputName"/>
      <input onChange={(e)=> userNumberf(e) } type="text" name="userInputNumber" placeholder="write your phone number" className="userInputNumber"/>
      <input onChange={(e)=> sendNumberf(e) } type="text" name="sendInputNumber" placeholder="write the phone number you want to send a message" className="sendInputNumber"/>
     <div id="chatSection">
        <div className="chat-window"></div>
          <label className="chat-label">
            Enter a message:
            <input onChange={(e)=> setChatInput(e.target.value) } type="text" name="chatInput" className="chatInput" />
          </label>
          <button onClick={handleSubmit} className="chat-submit">submit</button>
      </div>
    </div>


    </>
  );
}

export default App;
