const cors = require('cors')
const express = require('express')

const app = express()
const server = require('http').createServer(app)
const port = process.env.PORT || 5000
const io = require('socket.io')(server)

app.use(cors())

const getApiAndEmit = socket => {
  const response = new Date();
  // Emitting a new message. Will be consumed by the client
  socket.emit("FromAPI", response);
};
// import path among other dependencies
const path = require('path')
app.use(express.static(path.join(__dirname + '/public')))

io.on('connection', socket => {
  socket.userName = 'Anonymous'
  console.log('Some client connected')
  socket.on('userName', userName => {
    console.log('From client: ', userName)
    socket.userName = userName
  })
  socket.on('userNumber', userNumber => {
    console.log('From client: ', userNumber)
    socket.userNumber = userNumber
  })
  socket.on('sendNumber', sendNumber => {
    console.log('From client: ', sendNumber)
    socket.sendNumber = sendNumber
    if (socket.sendNumber > socket.userNumber) {
      socket.userRoom = socket.userNumber + socket.sendNumber
    } else {      
      socket.userRoom = socket.sendNumber + socket.userNumber
    }
    socket.join(socket.userRoom)
  })  
  // socket.on('userRoom', userRoom => {
  //   console.log('From client: ', userRoom)
  //   socket.userRoom = userRoom
  // 	socket.join(userRoom)
  // })
  // console.log(socket.userRoom)
  socket.on('chat', message => {
  console.log('not join',socket.userRoom)
    console.log('From client: ', message)
    io.to(socket.userRoom).emit('chat', {message : message, userName : socket.userName})
  })
})	

server.listen(port, () => {
  console.log(`Server running on port: ${port}`)
})